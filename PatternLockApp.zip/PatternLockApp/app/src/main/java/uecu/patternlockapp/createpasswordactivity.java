package uecu.patternlockapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

public class createpasswordactivity extends AppCompatActivity {
    PatternLockView mPatternLockView;
    TextView dc;
    int count;
    String passcheck="";
    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_password);
        dc=(TextView)findViewById(R.id.dotcount);

        mPatternLockView = (PatternLockView) findViewById(R.id.pattern_lock_view);
        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {
                dc.setText("Lift Your Finger when Done...");
                dc.setVisibility(View.VISIBLE);

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {
                count=countdot(Integer.parseInt(PatternLockUtils.patternToString(mPatternLockView,progressPattern)));
                if(count<3)
                {
                    dc.setText("Connect Atleast 3 dots...");
                    dc.setVisibility(View.VISIBLE);

                }
                if(count>2)
                {
                    dc.setVisibility(View.INVISIBLE);

                }

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {

                if(count>2) {
                    dc.setVisibility(View.INVISIBLE);
                    passcheck=PatternLockUtils.patternToString(mPatternLockView, pattern);

                    //SharedPreferences preferences = getSharedPreferences("PREFS", 0);
                    //SharedPreferences.Editor editor = preferences.edit();
                    //editor.putString("passwordcheck", PatternLockUtils.patternToString(mPatternLockView, pattern));
                    //editor.apply();
                    Intent intent = new Intent(getApplicationContext(), confirmpatternactivity.class);
                    intent.putExtra("passcheckstring",passcheck);
                    startActivity(intent);
                    finish();

                }else {
                    mPatternLockView.clearPattern();
                }

            }

            @Override
            public void onCleared() {

            }
        });

    }
    private int countdot(int c)
    {
        int x=0;
        while(c>0)
        {
            x++;
            c/=10;
        }
        return x;

    }

}
