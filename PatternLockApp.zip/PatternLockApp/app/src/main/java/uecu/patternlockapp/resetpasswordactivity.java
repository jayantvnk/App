package uecu.patternlockapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class resetpasswordactivity extends AppCompatActivity {

    private Button btn,cancelbtn;
   private EditText uname;
    private EditText upass;
   private String muser="admin",mpass="admin";
    @Override
    protected  void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);

        setContentView(R.layout.resetpassword);
        SharedPreferences preferences= getSharedPreferences("PREFS",0);
        muser= preferences.getString("user","admin");
        mpass= preferences.getString("pwd","admin");

        btn = (Button)findViewById(R.id.resetbutton);
        uname=(EditText) findViewById(R.id.name);
        upass=(EditText) findViewById(R.id.password);
        cancelbtn=(Button)findViewById(R.id.cancel);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(uname.getText().toString(),upass.getText().toString());
            }
        });
        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), inputpasswordactivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private  void validate(String username, String userpassword){
        if((username.equals(muser))&&(userpassword.equals(mpass))){
            Intent intent = new Intent(getApplicationContext(), createpasswordactivity.class);
            startActivity(intent);
            finish();
        }
        else{
            Toast.makeText(resetpasswordactivity.this,"Incorrect User Details!",Toast.LENGTH_SHORT).show();
        }
    }
}
