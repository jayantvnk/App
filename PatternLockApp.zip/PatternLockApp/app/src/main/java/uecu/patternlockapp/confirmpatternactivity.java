package uecu.patternlockapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;
import com.andrognito.patternlockview.utils.ResourceUtils;

import java.util.List;

public class confirmpatternactivity extends AppCompatActivity {
    PatternLockView mPatternLockView;
    Button drawagain,confirm;


    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_pattern);
        Bundle extras = getIntent().getExtras();
        final String passcheck = extras.getString("passcheckstring");
        drawagain=(Button)findViewById(R.id.drawagain);
        confirm=(Button)findViewById(R.id.confirm);
        mPatternLockView = (PatternLockView) findViewById(R.id.pattern_lock_view_confirm);

        drawagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), createpasswordactivity.class);

                startActivity(intent);
                finish();
            }
        });




        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(final List<PatternLockView.Dot> pattern) {

                if(passcheck.equals(PatternLockUtils.patternToString(mPatternLockView, pattern))) {
                    mPatternLockView.setCorrectStateColor(ResourceUtils.getColor(confirmpatternactivity.this, R.color.green));

                    confirm.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            SharedPreferences preferences = getSharedPreferences("PREFS", 0);
                            SharedPreferences.Editor editor = preferences.edit();
                            editor.putString("password", PatternLockUtils.patternToString(mPatternLockView, pattern));
                            editor.apply();
                            Toast.makeText(confirmpatternactivity.this, "Pattern saved Successfully!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), programactivity.class);
                            startActivity(intent);
                            finish();


                        }
                    });
                }else
                {
                    Toast.makeText(confirmpatternactivity.this,"Pattern does not match!",Toast.LENGTH_SHORT).show();
                    mPatternLockView.setCorrectStateColor(ResourceUtils.getColor(confirmpatternactivity.this, R.color.primary));
                }

                }



            @Override
            public void onCleared() {

            }
        });

    }
}
