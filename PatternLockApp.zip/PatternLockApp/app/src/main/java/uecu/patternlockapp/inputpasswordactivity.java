package uecu.patternlockapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.patternlockview.PatternLockView;
import com.andrognito.patternlockview.listener.PatternLockViewListener;
import com.andrognito.patternlockview.utils.PatternLockUtils;

import java.util.List;

public class inputpasswordactivity extends AppCompatActivity {
    PatternLockView mPatternLockView;
    String password;
    int count=5;
    TextView forgotpass, counttv;
    @Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_password);
        SharedPreferences preferences= getSharedPreferences("PREFS",0);
        password= preferences.getString("password","0");
        forgotpass= (TextView) findViewById(R.id.forgotpassword);
        counttv=(TextView)findViewById(R.id.count);
        forgotpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=5;
                Intent intent1 = new Intent(getApplicationContext(), resetpasswordactivity.class);
                startActivity(intent1);
                finish();


            }
        });

        mPatternLockView = (PatternLockView) findViewById(R.id.pattern_lock_view);
        mPatternLockView.addPatternLockListener(new PatternLockViewListener() {
            @Override
            public void onStarted() {

            }

            @Override
            public void onProgress(List<PatternLockView.Dot> progressPattern) {

            }

            @Override
            public void onComplete(List<PatternLockView.Dot> pattern) {
                if(count>0) {
                    if (password.equals(PatternLockUtils.patternToString(mPatternLockView, pattern))) {
                        Intent intent = new Intent(getApplicationContext(), programactivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        count--;
                        counttv.setText("Attempts Left: "+count);
                        Toast.makeText(inputpasswordactivity.this, "Incorrect Password!", Toast.LENGTH_SHORT).show();
                        mPatternLockView.clearPattern();
                    }
                }
                else{
                    Toast.makeText(inputpasswordactivity.this, "Maximum Attempts limit Reached!", Toast.LENGTH_SHORT).show();
                    mPatternLockView.clearPattern();
                }
            }

            @Override
            public void onCleared() {

            }
        });
    }

}
