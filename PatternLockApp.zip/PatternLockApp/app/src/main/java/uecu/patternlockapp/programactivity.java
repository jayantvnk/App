package uecu.patternlockapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class programactivity extends AppCompatActivity {
@Override
    protected  void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_program);
    }
@Override
    public boolean onCreateOptionsMenu(Menu menu){
    getMenuInflater().inflate(R.menu.menu,menu);
    return  true;
}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()){
        case R.id.logoutMenu:{
            Intent intent = new Intent(getApplicationContext(), inputpasswordactivity.class);
            startActivity(intent);
            finish();
        }
        break;
        case R.id.resetsettingMenu:{


            Intent intent = new Intent(getApplicationContext(), securitypasswordactivity.class);
            startActivity(intent);

            finish();


        }
        break;
        case R.id.resetpatternMenu:{

            Intent intent = new Intent(getApplicationContext(), resetpasswordactivity.class);
            startActivity(intent);

            finish();
        }

        break;
    }
        return super.onOptionsItemSelected(item);
    }
}
